<?php

namespace ContainerZAnuCAT;

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    private $valueHolder0a42e = null;
    private $initializer5e2af = null;
    private static $publicProperties16ad9 = [
        
    ];
    public function getConnection()
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'getConnection', array(), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->getConnection();
    }
    public function getMetadataFactory()
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'getMetadataFactory', array(), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->getMetadataFactory();
    }
    public function getExpressionBuilder()
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'getExpressionBuilder', array(), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->getExpressionBuilder();
    }
    public function beginTransaction()
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'beginTransaction', array(), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->beginTransaction();
    }
    public function getCache()
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'getCache', array(), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->getCache();
    }
    public function transactional($func)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'transactional', array('func' => $func), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->transactional($func);
    }
    public function wrapInTransaction(callable $func)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'wrapInTransaction', array('func' => $func), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->wrapInTransaction($func);
    }
    public function commit()
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'commit', array(), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->commit();
    }
    public function rollback()
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'rollback', array(), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->rollback();
    }
    public function getClassMetadata($className)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'getClassMetadata', array('className' => $className), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->getClassMetadata($className);
    }
    public function createQuery($dql = '')
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'createQuery', array('dql' => $dql), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->createQuery($dql);
    }
    public function createNamedQuery($name)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'createNamedQuery', array('name' => $name), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->createNamedQuery($name);
    }
    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->createNativeQuery($sql, $rsm);
    }
    public function createNamedNativeQuery($name)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->createNamedNativeQuery($name);
    }
    public function createQueryBuilder()
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'createQueryBuilder', array(), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->createQueryBuilder();
    }
    public function flush($entity = null)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'flush', array('entity' => $entity), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->flush($entity);
    }
    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->find($className, $id, $lockMode, $lockVersion);
    }
    public function getReference($entityName, $id)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->getReference($entityName, $id);
    }
    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->getPartialReference($entityName, $identifier);
    }
    public function clear($entityName = null)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'clear', array('entityName' => $entityName), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->clear($entityName);
    }
    public function close()
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'close', array(), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->close();
    }
    public function persist($entity)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'persist', array('entity' => $entity), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->persist($entity);
    }
    public function remove($entity)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'remove', array('entity' => $entity), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->remove($entity);
    }
    public function refresh($entity)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'refresh', array('entity' => $entity), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->refresh($entity);
    }
    public function detach($entity)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'detach', array('entity' => $entity), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->detach($entity);
    }
    public function merge($entity)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'merge', array('entity' => $entity), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->merge($entity);
    }
    public function copy($entity, $deep = false)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->copy($entity, $deep);
    }
    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->lock($entity, $lockMode, $lockVersion);
    }
    public function getRepository($entityName)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'getRepository', array('entityName' => $entityName), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->getRepository($entityName);
    }
    public function contains($entity)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'contains', array('entity' => $entity), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->contains($entity);
    }
    public function getEventManager()
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'getEventManager', array(), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->getEventManager();
    }
    public function getConfiguration()
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'getConfiguration', array(), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->getConfiguration();
    }
    public function isOpen()
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'isOpen', array(), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->isOpen();
    }
    public function getUnitOfWork()
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'getUnitOfWork', array(), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->getUnitOfWork();
    }
    public function getHydrator($hydrationMode)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->getHydrator($hydrationMode);
    }
    public function newHydrator($hydrationMode)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->newHydrator($hydrationMode);
    }
    public function getProxyFactory()
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'getProxyFactory', array(), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->getProxyFactory();
    }
    public function initializeObject($obj)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'initializeObject', array('obj' => $obj), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->initializeObject($obj);
    }
    public function getFilters()
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'getFilters', array(), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->getFilters();
    }
    public function isFiltersStateClean()
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'isFiltersStateClean', array(), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->isFiltersStateClean();
    }
    public function hasFilters()
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'hasFilters', array(), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return $this->valueHolder0a42e->hasFilters();
    }
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;
        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);
        $instance->initializer5e2af = $initializer;
        return $instance;
    }
    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;
        if (! $this->valueHolder0a42e) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder0a42e = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
        }
        $this->valueHolder0a42e->__construct($conn, $config, $eventManager);
    }
    public function & __get($name)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, '__get', ['name' => $name], $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        if (isset(self::$publicProperties16ad9[$name])) {
            return $this->valueHolder0a42e->$name;
        }
        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');
        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder0a42e;
            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }
        $targetObject = $this->valueHolder0a42e;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();
        return $returnValue;
    }
    public function __set($name, $value)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');
        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder0a42e;
            $targetObject->$name = $value;
            return $targetObject->$name;
        }
        $targetObject = $this->valueHolder0a42e;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();
        return $returnValue;
    }
    public function __isset($name)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, '__isset', array('name' => $name), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');
        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder0a42e;
            return isset($targetObject->$name);
        }
        $targetObject = $this->valueHolder0a42e;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();
        return $returnValue;
    }
    public function __unset($name)
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, '__unset', array('name' => $name), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');
        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder0a42e;
            unset($targetObject->$name);
            return;
        }
        $targetObject = $this->valueHolder0a42e;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);
            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }
    public function __clone()
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, '__clone', array(), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        $this->valueHolder0a42e = clone $this->valueHolder0a42e;
    }
    public function __sleep()
    {
        $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, '__sleep', array(), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
        return array('valueHolder0a42e');
    }
    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }
    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer5e2af = $initializer;
    }
    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer5e2af;
    }
    public function initializeProxy() : bool
    {
        return $this->initializer5e2af && ($this->initializer5e2af->__invoke($valueHolder0a42e, $this, 'initializeProxy', array(), $this->initializer5e2af) || 1) && $this->valueHolder0a42e = $valueHolder0a42e;
    }
    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder0a42e;
    }
    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder0a42e;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
